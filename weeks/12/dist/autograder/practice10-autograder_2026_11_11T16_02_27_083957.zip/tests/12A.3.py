OK_FORMAT = True

test = {   'name': '12A.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert any((isinstance(step, SMOTE) for step in knn_smote.named_steps.values())), 'the pipeline needs a SMOTE(random_state=1) step'\n"
                                               '>>> assert isinstance(knn_smote[-1], KNeighborsClassifier), "the pipeline\'s last step should be KNeighborsClassifier()"\n'
                                               '>>> assert \'test_recall\' in knn_smote_scores and len(knn_smote_scores[\'test_recall\']) == 5, "cross_validate with cv=5 and scoring=[\'recall\', '
                                               '\'precision\']"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert abs(knn_smote_scores['test_recall'].mean() - 0.97143) < 0.0005\n"
                                               ">>> assert abs(knn_smote_scores['test_precision'].mean() - 0.63367) < 0.0005\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
