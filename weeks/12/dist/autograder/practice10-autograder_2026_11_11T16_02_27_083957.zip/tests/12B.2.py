OK_FORMAT = True

test = {   'name': '12B.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert 300 < mae_calendar < 900 and 150 < mae_lags < 500, 'fit on births.loc[learn, ...] and y[learn]; score on births.loc[test, ...] and "
                                               "y[test]'\n"
                                               ">>> assert mae_lags < mae_calendar, 'the second forest should use calendar + lags'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(mae_calendar - 626.39) < 0.01\n>>> assert abs(mae_lags - 298.6) < 0.01\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
