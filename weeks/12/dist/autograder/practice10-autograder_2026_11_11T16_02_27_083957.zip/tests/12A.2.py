OK_FORMAT = True

test = {   'name': '12A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert len(p_train) == len(y_train) and 0 <= p_train.min() and (p_train.max() <= 1), "cross_val_predict(..., method=\'predict_proba\')[:, 1] on '
                                               'X_train, y_train"\n'
                                               ">>> assert len(called) == len(y_test), 'called should have one True/False per test Pokémon'\n"
                                               ">>> assert 0 < rec_02 <= 1 and 0 < prec_02 <= 1, 'recall_score and precision_score with (y_test, called)'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert (p_train >= 0.5).sum() == 30\n'
                                               '>>> assert (p_train >= 0.2).sum() == 47\n'
                                               '>>> assert called.sum() == 16\n'
                                               '>>> assert abs(rec_02 - 1.0) < 1e-09\n'
                                               '>>> assert abs(prec_02 - 0.75) < 1e-09\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
