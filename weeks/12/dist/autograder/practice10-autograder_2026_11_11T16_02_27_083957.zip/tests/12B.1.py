OK_FORMAT = True

test = {   'name': '12B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert {'births_1d_ago', 'births_7d_ago', 'births_364d_ago', 'mean_last_7'} <= set(births.columns), 'add the four lag columns'\n"
                                               '>>> assert (births[\'births_7d_ago\'].iloc[7:].to_numpy() == births[\'births\'].shift(7).iloc[7:].to_numpy()).all(), "births_7d_ago should be '
                                               'births[\'births\'].shift(7): a past value, so a positive shift"\n'
                                               ">>> assert len(births) == 5115 and learn.sum() == 3289, 'add the columns before the given dropna'\n"
                                               '>>> assert 300 < naive_mae < 600, "mean_absolute_error(y[test], births.loc[test, \'births_7d_ago\'])"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(naive_mae - 452.0613) < 0.001\n'
                                               ">>> assert abs(births['mean_last_7'].iloc[100] - births['births'].iloc[93:100].mean()) < 1e-09\n"
                                               ">>> assert (births['births_364d_ago'].iloc[364:].to_numpy() == births['births'].iloc[:-364].to_numpy()).all()\n"
                                               ">>> assert abs(mean_absolute_error(y[test], births.loc[test, 'births_364d_ago']) - 377.53) < 0.01\n"
                                               ">>> assert abs(mean_absolute_error(y[test], births.loc[test, 'mean_last_7']) - 2003.55) < 0.01\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
