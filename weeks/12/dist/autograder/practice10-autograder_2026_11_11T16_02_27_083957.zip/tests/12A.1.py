OK_FORMAT = True

test = {   'name': '12A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert hasattr(model, 'steps') and isinstance(model[0], StandardScaler) and isinstance(model[-1], LogisticRegression), "
                                               "'make_pipeline(StandardScaler(), LogisticRegression())'\n"
                                               ">>> assert len(y_pred) == len(y_test), 'predict on X_test'\n"
                                               ">>> assert 0.9 < acc < 1 and 0 < rec < 1 and (0 < prec < 1), 'use accuracy_score, recall_score and precision_score with (y_test, y_pred)'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(acc - 0.93923) < 0.0005\n>>> assert abs(rec - 0.33333) < 0.0005\n>>> assert abs(prec - 0.57143) < 0.0005\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
