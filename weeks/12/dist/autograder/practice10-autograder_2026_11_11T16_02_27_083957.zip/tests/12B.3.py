OK_FORMAT = True

test = {   'name': '12B.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(shuffled_mae) == 5 and len(rolling_mae) == 5, 'cross_val_score with 5 folds, twice'\n"
                                               '>>> assert (shuffled_mae > 0).all() and (rolling_mae > 0).all(), "put a minus sign in front of cross_val_score(..., '
                                               'scoring=\'neg_mean_absolute_error\')"\n'
                                               ">>> assert rolling_mae.mean() > shuffled_mae.mean(), 'shuffled_mae uses KFold(n_splits=5, shuffle=True, random_state=1); rolling_mae uses "
                                               "TimeSeriesSplit(n_splits=5)'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(shuffled_mae.mean() - 276.81) < 0.01\n'
                                               '>>> assert abs(rolling_mae.mean() - 410.08) < 0.01\n'
                                               '>>> assert abs(rolling_mae[-1] - 586.4) < 0.1\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
