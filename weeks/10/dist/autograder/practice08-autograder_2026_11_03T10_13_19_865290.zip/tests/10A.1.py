OK_FORMAT = True

test = {   'name': '10A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(line, LinearRegression) and line.n_features_in_ == 1, "fit the line on X_train[[\'weight\']] only"\n'
                                               ">>> assert slope < 0, 'heavier cars should get fewer miles per gallon'\n"
                                               ">>> assert 15 < mpg_3000 < 35, 'predict for a single 3,000 lb car and take element [0]'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(slope - -0.0077744) < 1e-06\n>>> assert abs(intercept - 46.58553) < 0.0005\n>>> assert abs(mpg_3000 - 23.26221) < 0.0005\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
