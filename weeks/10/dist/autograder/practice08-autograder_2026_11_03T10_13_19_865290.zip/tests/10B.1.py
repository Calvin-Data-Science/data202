OK_FORMAT = True

test = {   'name': '10B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(ridge_search, GridSearchCV) and ridge_search.cv == 5, 'use GridSearchCV with cv=5'\n"
                                               '>>> assert isinstance(ridge_search.estimator[-1], Ridge), "the pipeline\'s last step should be Ridge()"\n'
                                               ">>> assert hasattr(ridge_search, 'best_estimator_'), 'fit the search on few and few_mpg'\n"
                                               ">>> assert 'mean_train_score' in ridge_search.cv_results_, 'use return_train_score=True'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert ridge_search.best_params_['ridge__alpha'] == 10\n>>> assert abs(-ridge_search.best_score_ - 4.21563) < 0.0005\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
