OK_FORMAT = True

test = {   'name': '10C.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(residuals) == len(y_test), 'one residual per test car'\n>>> assert len(by_era) == 3, 'one average per era'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert abs(by_era['1978-82'] - 2.32268) < 0.0005\n>>> assert abs(by_era['1970-73'] - -2.25696) < 0.0005\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
