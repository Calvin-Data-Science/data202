OK_FORMAT = True

test = {   'name': '10B.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(lasso_search, GridSearchCV) and lasso_search.cv == 5, 'use GridSearchCV with cv=5'\n"
                                               '>>> assert isinstance(lasso_search.estimator[-1], Lasso), "the pipeline\'s last step should be Lasso(max_iter=100_000)"\n'
                                               ">>> assert hasattr(lasso_search, 'best_estimator_'), 'fit the search on few and few_mpg'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert lasso_search.best_params_['lasso__alpha'] == 1\n>>> assert list(lasso_slopes[lasso_slopes != 0].index) == ['displacement', 'model_year']\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
