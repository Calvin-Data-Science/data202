OK_FORMAT = True

test = {   'name': '10A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(two, LinearRegression) and two.n_features_in_ == 2, "fit on X_train[[\'weight\', \'model_year\']]"\n'
                                               ">>> assert weight_slope < 0 < year_slope, 'weight first, then model_year'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(weight_slope - -0.0066768) < 1e-06\n>>> assert abs(year_slope - 0.79325) < 0.0005\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
