OK_FORMAT = True

test = {   'name': '10C.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(predicted) == len(y_test), 'predict the test cars'\n"
                                               ">>> assert 0 < mae <= rmse, 'RMSE is never smaller than MAE'\n"
                                               ">>> assert 0 < r2 < 1, 'R² should lie between 0 and 1 here'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(mae - 2.88813) < 0.0005\n>>> assert abs(rmse - 3.77821) < 0.0005\n>>> assert abs(r2 - 0.73941) < 0.0005\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
