OK_FORMAT = True

test = {   'name': 't2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert lo == 10\n>>> assert hi == 50\n>>> assert avg == 30.0\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
