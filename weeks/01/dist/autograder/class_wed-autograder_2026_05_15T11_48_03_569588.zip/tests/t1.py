OK_FORMAT = True

test = {   'name': 't1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert temps_c == [0, 20, 37, 100], 'temps_c should be unchanged'\n"
                                               ">>> assert temps_f == [32.0, 68.0, 98.6, 212.0], 'check your Fahrenheit formula'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
