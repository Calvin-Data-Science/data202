OK_FORMAT = True

test = {   'name': 't5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert location['city'] == 'Grand Rapids'\n>>> assert location['state'] == 'Michigan'\n>>> assert location['zip'] == '49546'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
