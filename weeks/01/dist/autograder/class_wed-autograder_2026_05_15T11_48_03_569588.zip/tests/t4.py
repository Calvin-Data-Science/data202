OK_FORMAT = True

test = {   'name': 't4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert words == ['Machine', 'learning', 'IS', 'fascinating'], 'words should be unchanged'\n"
                                               ">>> assert lower_words == ['machine', 'learning', 'is', 'fascinating']\n"
                                               ">>> assert sorted_words == ['fascinating', 'is', 'learning', 'machine']\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
