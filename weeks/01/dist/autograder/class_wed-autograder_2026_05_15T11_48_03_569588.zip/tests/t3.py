OK_FORMAT = True

test = {   'name': 't3',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> assert codes == [2, 0, 1, 2, 0]\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
