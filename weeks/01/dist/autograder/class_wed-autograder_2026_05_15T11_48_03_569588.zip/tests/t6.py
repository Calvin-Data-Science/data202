OK_FORMAT = True

test = {   'name': 't6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert avg_per_student.shape == (4,)\n'
                                               '>>> assert avg_per_assignment.shape == (3,)\n'
                                               ">>> assert best_student == 2, 'student index 2 has the highest average'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
