OK_FORMAT = True

test = {   'name': '06A.2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(scores) == 26, 'one row per k in ks'\n"
                                               ">>> assert scores.drop(columns='k').apply(lambda c: c.between(0, 1).all()).all(), 'scores lie between 0 and 1'\n"
                                               '>>> assert scores.loc[0, \'recall_train\'] > 0.99, "k = 1 on the training set: each message\'s nearest neighbor is itself"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert abs(scores.loc[0, 'recall_test'] - 0.82) < 0.005\n"
                                               ">>> assert abs(scores.loc[25, 'recall_test'] - 0.539) < 0.005\n"
                                               ">>> assert abs(scores.loc[1, 'precision_test'] - 0.98) < 0.005\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
