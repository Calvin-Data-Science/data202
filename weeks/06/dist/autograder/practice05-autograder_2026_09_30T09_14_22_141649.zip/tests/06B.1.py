OK_FORMAT = True

test = {   'name': '06B.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert list(cm.index) == ['ham', 'spam'] and list(cm.columns) == ['ham', 'spam']\n"
                                               ">>> assert cm.values.sum() == 1032, 'every test message should be counted once'\n"
                                               ">>> assert all((0 <= m <= 1 for m in [accuracy, precision, recall])), 'metrics lie between 0 and 1'\n"
                                               ">>> assert abs(accuracy - np.trace(cm.values) / 1032) < 1e-09, 'accuracy = the diagonal / all messages'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert cm.loc['spam', 'spam'] == 97 and cm.loc['ham', 'spam'] == 2\n"
                                               '>>> assert abs(precision - 97 / 99) < 1e-06 and abs(recall - 97 / 128) < 1e-06\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
