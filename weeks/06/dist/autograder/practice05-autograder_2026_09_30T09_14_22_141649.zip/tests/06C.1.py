OK_FORMAT = True

test = {   'name': '06C.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(text_train) == 4128 and len(text_test) == 1032, 'use test_size=0.2'\n"
                                               ">>> assert len(y_train) == len(text_train) and len(y_test) == len(text_test), 'split the messages and y together'\n"
                                               ">>> assert abs(y_train.mean() - y_test.mean()) < 0.002, 'use stratify=y so both sets keep the same share of spam'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert text_test.index[:3].tolist() == train_test_split(sms['text'], y, test_size=0.2, stratify=y, random_state=42)[1].index[:3].tolist()\n"
                                               '>>> assert y_test.sum() == 128\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
