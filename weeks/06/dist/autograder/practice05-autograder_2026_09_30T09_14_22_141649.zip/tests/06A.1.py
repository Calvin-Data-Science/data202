OK_FORMAT = True

test = {   'name': '06A.1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert knn.n_neighbors == 5, 'use k = 5'\n>>> assert len(y_pred) == 1032, 'predict the test messages'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert knn.metric == 'cosine'\n>>> assert y_pred.sum() == 99\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
