OK_FORMAT = True

test = {   'name': '09A.3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(onehot.get_feature_names_out()) == 6, 'fit on X_train[words]: 3 species + 3 intake types'\n"
                                               ">>> assert list(ordinal.categories_[0]) == sizes, 'pass categories=[sizes] so the codes go from smallest to largest'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
