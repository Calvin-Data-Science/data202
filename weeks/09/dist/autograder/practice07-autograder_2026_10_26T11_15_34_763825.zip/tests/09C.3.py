OK_FORMAT = True

test = {   'name': '09C.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(fill_body[0], StandardScaler) and isinstance(fill_body[-1], KNNImputer), 'StandardScaler, then KNNImputer'\n"
                                               ">>> assert isinstance(flag_behavior[0], SimpleImputer) and flag_behavior[0].add_indicator, 'SimpleImputer with add_indicator=True, then "
                                               "StandardScaler'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(cv_mechanism - 0.764) < 0.0005\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
