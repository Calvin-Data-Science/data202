OK_FORMAT = True

test = {   'name': '09C.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert blank_by_intake.shape == (3, 3), 'one row per intake type, one column per blank column'\n"
                                               ">>> assert blank_by_intake.max().max() <= 1, 'shares of blanks lie between 0 and 1'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert abs(blank_by_intake.loc['Stray', 'age_years'] - 0.39377) < 0.0005\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
