OK_FORMAT = True

test = {   'name': '09A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert 0 < cv_raw < 1 and 0 < cv_scaled < 1, 'store the MEAN of the 5 scores'\n"
                                               ">>> assert cv_scaled > cv_raw, 'put a StandardScaler in front of kNN for cv_scaled'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(cv_raw - 0.66047) < 0.0005\n>>> assert abs(cv_scaled - 0.73357) < 0.0005\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
