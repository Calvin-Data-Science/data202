OK_FORMAT = True

test = {   'name': '09B.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(model, Pipeline) and list(model.named_steps) == ['prep', 'knn'], 'two steps: prep and knn'\n"
                                               ">>> assert isinstance(preprocess, ColumnTransformer) and len(preprocess.transformers) == 3, 'three branches: num, size, words'\n"
                                               ">>> assert 0 < cv_pipe < 1, 'store the MEAN of the 5 scores'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(cv_pipe - 0.77743) < 0.0005\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
