OK_FORMAT = True

test = {   'name': '09B.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(grid, GridSearchCV) and grid.cv == 5, 'use GridSearchCV with cv=5'\n"
                                               ">>> assert hasattr(grid, 'best_estimator_'), 'fit the grid search on the training set'\n"
                                               ">>> assert 'mean_train_score' in grid.cv_results_, 'use return_train_score=True'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert best_k == 15\n>>> assert abs(best_cv - 0.77743) < 0.0005\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
