OK_FORMAT = True

test = {   'name': '11B.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(ada, AdaBoostClassifier), 'use AdaBoostClassifier'\n"
                                               ">>> assert ada.n_estimators == 100 and ada.random_state == 1, 'use n_estimators=100 and random_state=1'\n"
                                               ">>> assert 'train_score' in ada_scores and len(ada_scores['test_score']) == 5, 'use cross_validate with cv=5 and return_train_score=True'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert abs(ada_scores['test_score'].mean() - 0.455) < 0.01\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
