OK_FORMAT = True

test = {   'name': '11A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert slopes.shape == (6, 10), 'one row per genre and one column per feature: fit logistic first'\n"
                                               ">>> assert list(slopes.columns) == features, 'use columns=features'\n"
                                               '>>> assert rap_top in features and rock_bottom in features, "store a column name, like \'energy\'"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert rap_top == 'speechiness'\n"
                                               ">>> assert rock_bottom == 'danceability'\n"
                                               ">>> assert abs(slopes.loc['rock', 'danceability'] - -1.28517) < 0.0005\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
