OK_FORMAT = True

test = {   'name': '11A.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(probs) == 6 and abs(probs.sum() - 1) < 1e-06, 'six probabilities, one per genre, that add up to 1'\n"
                                               '>>> assert guess in logistic.classes_, "guess should be one genre, like \'rock\'"\n'
                                               ">>> assert guess == probs.idxmax(), 'use logistic.predict(mi_gente)[0]'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert guess == 'edm'\n>>> assert abs(probs['edm'] - 0.3131) < 0.0005\n>>> assert abs(probs['latin'] - 0.1639) < 0.0005\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
