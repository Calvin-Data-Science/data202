OK_FORMAT = True

test = {   'name': '11B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(forest, RandomForestClassifier), 'use RandomForestClassifier'\n"
                                               ">>> assert forest.n_estimators == 100 and forest.random_state == 1, 'use n_estimators=100 and random_state=1'\n"
                                               ">>> assert 'train_score' in forest_scores and len(forest_scores['test_score']) == 5, 'use cross_validate with cv=5 and return_train_score=True'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert abs(forest_scores['test_score'].mean() - 0.51733) < 0.0005\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
