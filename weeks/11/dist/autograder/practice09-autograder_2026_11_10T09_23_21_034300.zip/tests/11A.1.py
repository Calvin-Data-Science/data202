OK_FORMAT = True

test = {   'name': '11A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert hasattr(logistic, 'steps') and isinstance(logistic[0], StandardScaler), 'make_pipeline(StandardScaler(), "
                                               "LogisticRegression(max_iter=1000))'\n"
                                               '>>> assert isinstance(logistic[-1], LogisticRegression), "the pipeline\'s last step should be LogisticRegression(max_iter=1000)"\n'
                                               ">>> assert 'train_score' in logistic_scores and len(logistic_scores['test_score']) == 5, 'use cross_validate with cv=5 and return_train_score=True'\n"
                                               ">>> assert 0.35 < logistic_scores['test_score'].mean() < 0.6, 'cross-validate on X_train and y_train'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert abs(logistic_scores['test_score'].mean() - 0.45578) < 0.0005\n>>> assert abs(logistic_scores['train_score'].mean() - 0.46389) < 0.0005\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
