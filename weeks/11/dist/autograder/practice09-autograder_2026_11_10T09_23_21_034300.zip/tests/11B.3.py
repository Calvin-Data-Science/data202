OK_FORMAT = True

test = {   'name': '11B.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert 0.3 < logistic_test < 0.7 and 0.3 < forest_test < 0.7 and (0.3 < ada_test < 0.7), 'use .score(X_test, y_test) after fitting on X_train, "
                                               "y_train'\n"
                                               ">>> assert forest_test > logistic_test, 'fit each model on the training songs, then score it on the test songs'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(logistic_test - 0.468) < 0.0005\n>>> assert abs(forest_test - 0.52467) < 0.0005\n>>> assert 0.43 < ada_test < 0.5\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
