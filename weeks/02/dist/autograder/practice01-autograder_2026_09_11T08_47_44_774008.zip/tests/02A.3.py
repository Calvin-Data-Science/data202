OK_FORMAT = True

test = {   'name': '02A.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert \'decade\' in fires.columns, "Column \'decade\' not found"\n'
                                               '>>> assert pd.api.types.is_string_dtype(fires[\'decade\']) or pd.api.types.is_object_dtype(fires[\'decade\']), "\'decade\' should be a string '
                                               'column"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert fires.loc[fires['year'] == 1998, 'decade'].iloc[0] == '1990s'\n"
                                               ">>> assert fires.loc[fires['year'] == 2005, 'decade'].iloc[0] == '2000s'\n"
                                               ">>> assert fires.loc[fires['year'] == 2015, 'decade'].iloc[0] == '2010s'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
