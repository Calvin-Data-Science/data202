OK_FORMAT = True

test = {   'name': '02B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(mato_grosso) > 0, 'mato_grosso is empty'\n>>> assert mato_grosso['state'].nunique() == 1, 'mato_grosso should contain only one state'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert mato_grosso['state'].iloc[0] == 'Mato Grosso'\n>>> assert len(mato_grosso) == 478\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
