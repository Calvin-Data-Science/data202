OK_FORMAT = True

test = {   'name': '02B.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(top5) == 5, 'top5 should have exactly 5 rows'\n"
                                               ">>> nums = list(top5['number'])\n"
                                               ">>> assert nums == sorted(nums, reverse=True), 'top5 should be sorted by number descending'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert top5['state'].iloc[0] == 'Amazonas'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
