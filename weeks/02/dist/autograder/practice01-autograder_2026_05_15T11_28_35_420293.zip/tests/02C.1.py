OK_FORMAT = True

test = {   'name': '02C.1',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert isinstance(fig1, go.Figure), 'fig1 should be a Plotly Figure'\n", 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert len(fig1.data) >= 1\n'
                                               ">>> assert fig1.data[0].type == 'scatter'\n"
                                               '>>> assert fig1.layout.title.text is not None and len(fig1.layout.title.text) > 0\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
