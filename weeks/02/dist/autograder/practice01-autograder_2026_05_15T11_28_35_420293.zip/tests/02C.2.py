OK_FORMAT = True

test = {   'name': '02C.2',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> assert isinstance(fig2, go.Figure), 'fig2 should be a Plotly Figure'\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert len(fig2.data) > 1, 'fig2 should have one trace per state'\n"
                                               '>>> assert fig2.layout.title.text is not None and len(fig2.layout.title.text) > 0\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
