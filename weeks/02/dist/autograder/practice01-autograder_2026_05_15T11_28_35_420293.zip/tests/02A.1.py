OK_FORMAT = True

test = {   'name': '02A.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(n_rows, int), 'n_rows should be an integer'\n"
                                               ">>> assert isinstance(n_cols, int), 'n_cols should be an integer'\n"
                                               ">>> assert n_cols == 5, 'fires should have 5 columns'\n"
                                               ">>> assert n_rows > 1000, 'n_rows seems too small'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert n_rows == 6454\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
