OK_FORMAT = True

test = {   'name': '02B.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert 'north_recent' in dir(), 'north_recent is not defined'\n"
                                               ">>> assert north_recent['year'].min() >= 2010, 'north_recent contains years before 2010'\n"
                                               ">>> assert north_recent['state'].isin(north_states).all(), 'north_recent contains states outside north_states'\n"
                                               ">>> assert len(north_recent) > 0, 'north_recent is empty'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert north_recent['state'].nunique() <= 7\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
