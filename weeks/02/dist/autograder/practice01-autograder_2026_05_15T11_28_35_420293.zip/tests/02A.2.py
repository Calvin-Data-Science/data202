OK_FORMAT = True

test = {   'name': '02A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(peak_state, str), 'peak_state should be a string'\n>>> assert total_fires > 0, 'total_fires should be positive'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert peak_state == 'Amazonas'\n>>> assert abs(total_fires - 698924.073) < 1\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
