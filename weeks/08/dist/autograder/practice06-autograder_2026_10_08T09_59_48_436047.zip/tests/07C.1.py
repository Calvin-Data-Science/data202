OK_FORMAT = True

test = {   'name': '07C.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(search, GridSearchCV) and search.cv == 5, 'use GridSearchCV with cv=5'\n"
                                               ">>> assert hasattr(search, 'best_estimator_'), 'fit the search on the training set'\n"
                                               ">>> assert n_fits == 360, 'count the combinations in grid, then multiply by the number of folds'\n"
                                               '>>> assert abs(best_cv - search.best_score_) < 1e-09\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert search.best_params_['max_depth'] == 4\n>>> assert abs(best_cv - 0.785) < 1e-06\n>>> assert abs(winner_test - 0.805) < 1e-06\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
