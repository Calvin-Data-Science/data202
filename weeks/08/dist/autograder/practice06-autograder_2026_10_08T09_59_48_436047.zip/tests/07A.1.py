OK_FORMAT = True

test = {   'name': '07A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert tree2.get_depth() == 2, 'use max_depth=2'\n"
                                               ">>> assert 0 <= train_acc <= 1 and 0 <= test_acc <= 1, 'accuracies lie between 0 and 1'\n"
                                               ">>> assert tree2.n_features_in_ == 3, 'fit on X_train (the three numeric features)'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(train_acc - 0.635) < 1e-06\n>>> assert abs(test_acc - 0.63) < 1e-06\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
