OK_FORMAT = True

test = {   'name': '07B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(fold_scores) == 5, 'use cv=5'\n"
                                               ">>> assert abs(cv_mean - np.mean(fold_scores)) < 1e-09, 'cv_mean is the mean of the 5 scores'\n"
                                               ">>> assert cv_mean < 0.95, 'score the tree on folds it did not see � not on the data it learned from'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(cv_mean - 0.63) < 1e-06\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
