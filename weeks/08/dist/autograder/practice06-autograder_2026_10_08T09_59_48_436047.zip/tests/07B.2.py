OK_FORMAT = True

test = {   'name': '07B.2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(cv_scores) == 22, 'one row per depth in depths'\n"
                                               ">>> assert cv_scores['mean'].between(0, 1).all(), 'mean scores lie between 0 and 1'\n"
                                               ">>> assert (cv_scores['spread'] > 0).all(), 'store the standard deviation of the 5 scores'\n"
                                               ">>> assert best_depth == cv_scores.loc[cv_scores['mean'].idxmax(), 'max_depth']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert best_depth == 4\n>>> assert abs(cv_scores.loc[3, 'mean'] - 0.78125) < 1e-06\n>>> assert abs(cv_scores.loc[1, 'mean'] - 0.6275) < 1e-06\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
