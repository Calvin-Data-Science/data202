OK_FORMAT = True

test = {   'name': '07A.3',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(scores) == 22, 'one row per depth in depths'\n"
                                               ">>> assert scores[['train', 'test']].apply(lambda c: c.between(0, 1).all()).all(), 'accuracies lie between 0 and 1'\n"
                                               ">>> assert scores['train'].is_monotonic_increasing, 'training accuracy should never drop as the tree gets deeper'\n"
                                               ">>> assert scores.loc[21, 'train'] == 1.0, 'at depth 22 every leaf is pure'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert scores.loc[0, 'leaves'] == 2 and scores.loc[21, 'leaves'] == 228\n"
                                               ">>> assert abs(scores.loc[3, 'test'] - 0.805) < 1e-06\n"
                                               ">>> assert abs(scores.loc[21, 'test'] - 0.655) < 1e-06\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
