OK_FORMAT = True

test = {   'name': '03B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(top5_nations) == 5, 'top5_nations should have exactly 5 rows'\n"
                                               ">>> goals = list(top5_nations['total_goals'])\n"
                                               ">>> assert goals == sorted(goals, reverse=True), 'top5_nations should be sorted by total_goals descending'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert top5_nations.iloc[0]['Nation_Code'] == 'ENG'\n>>> assert abs(top5_nations.iloc[0]['total_goals'] - 369) < 1\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
