OK_FORMAT = True

test = {   'name': '03A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert \'Primary_Pos\' in players.columns, "Column \'Primary_Pos\' not found"\n'
                                               ">>> assert players['Primary_Pos'].isin(['GK', 'DF', 'MF', 'FW']).all(), 'Primary_Pos should only contain the four base positions'\n"
                                               ">>> assert 0 < n_multi_position < len(players), 'n_multi_position should be a count between 0 and the number of players'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert n_multi_position == 162\n>>> assert players.loc[players['Player'] == 'Phil Foden', 'Primary_Pos'].iloc[0] == 'FW'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
