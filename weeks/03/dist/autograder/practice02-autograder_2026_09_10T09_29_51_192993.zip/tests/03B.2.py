OK_FORMAT = True

test = {   'name': '03B.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert 'total_yellow' in cards_by_age.columns and 'total_red' in cards_by_age.columns, 'cards_by_age should have total_yellow and total_red "
                                               "columns'\n"
                                               ">>> assert len(cards_by_age) == 3, 'cards_by_age should have one row per age group'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert abs(cards_by_age.loc[cards_by_age['Age Group'] == '< 25', 'total_yellow'].iloc[0] - 634) < 1\n"
                                               ">>> assert abs(cards_by_age.loc[cards_by_age['Age Group'] == '> 30', 'total_red'].iloc[0] - 9) < 1\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
