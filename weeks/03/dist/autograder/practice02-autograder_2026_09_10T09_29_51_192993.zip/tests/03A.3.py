OK_FORMAT = True

test = {   'name': '03A.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert \'Nation_Name\' in players.columns, "Column \'Nation_Name\' not found"\n'
                                               ">>> assert players.loc[players['Nation_Code'] == 'ESP', 'Nation_Name'].iloc[0] == 'Spain'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert players.loc[players['Player'] == 'Rodri', 'Nation_Name'].iloc[0] == 'Spain'\n"
                                               ">>> assert players.loc[players['Player'] == 'Erling Haaland', 'Nation_Name'].iloc[0] == 'NOR'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
