OK_FORMAT = True

test = {   'name': '03B.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(age_range_by_team) == 20, 'age_range_by_team should have one row per team'\n"
                                               '>>> vals = list(age_range_by_team)\n'
                                               ">>> assert vals == sorted(vals, reverse=True), 'age_range_by_team should be sorted descending'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert age_range_by_team.index[0] == 'Chelsea'\n>>> assert abs(age_range_by_team.iloc[0] - 21) < 1\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
