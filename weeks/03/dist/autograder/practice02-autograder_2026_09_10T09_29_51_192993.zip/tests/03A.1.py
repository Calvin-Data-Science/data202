OK_FORMAT = True

test = {   'name': '03A.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert \'Nation_Code\' in players.columns, "Column \'Nation_Code\' not found"\n'
                                               ">>> assert players['Nation_Code'].str.len().eq(3).all(), 'Nation_Code should be exactly 3 letters'\n"
                                               ">>> assert players['Nation_Code'].str.isupper().all(), 'Nation_Code should be uppercase'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert players.loc[players['Player'] == 'Rodri', 'Nation_Code'].iloc[0] == 'ESP'\n"
                                               ">>> assert players.loc[players['Player'] == 'Erling Haaland', 'Nation_Code'].iloc[0] == 'NOR'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
