OK_FORMAT = True

test = {   'name': '05A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert \'cluster\' in birds.columns, \'add a "cluster" column to birds\'\n'
                                               ">>> assert birds['cluster'].nunique() == 5, 'there should be exactly 5 clusters'\n"
                                               ">>> assert len(birds) == 4268, 'birds should still have one row per clip'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(kmeans.inertia_ - 1521.5) / 1521.5 < 0.02\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
