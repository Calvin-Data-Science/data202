OK_FORMAT = True

test = {   'name': '05A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert species_by_cluster.shape == (5, 5), '5 clusters (rows) x 5 species (columns)'\n"
                                               ">>> assert species_by_cluster.values.sum() == 4268, 'every clip should be counted once'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> shares = species_by_cluster.max(axis=1) / species_by_cluster.sum(axis=1)\n>>> assert shares.max() < 0.5\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
