OK_FORMAT = True

test = {   'name': '05C.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert X_2d.shape == (4268, 2), 'X_2d should have one row per clip and 2 columns'\n"
                                               ">>> assert 0 < share_2 < 1, 'share_2 is a share of the variance, between 0 and 1'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(share_2 - 0.7605) < 0.005\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
