OK_FORMAT = True

test = {   'name': '05B.1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(inertias) == 9 and len(sil_scores) == 9, 'one value per k, for k = 2 to 10'\n"
                                               ">>> assert np.all(np.diff(inertias) < 0), 'inertia should go down as k grows'\n"
                                               ">>> assert all((-1 <= s <= 1 for s in sil_scores)), 'silhouette scores lie between -1 and 1'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert abs(inertias[0] - 2453.6) / 2453.6 < 0.02\n>>> assert abs(sil_scores[0] - 0.29) < 0.02\n>>> assert best_k == 2\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
