OK_FORMAT = True

test = {   'name': '05A.4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert rec_by_cluster.shape == (377, 5), 'one row per recording (377), one column per cluster (5)'\n"
                                               ">>> assert len(top_share) == 377, 'one top share per recording'\n"
                                               ">>> assert 0 < avg_top_share <= 1, 'avg_top_share is an average of shares, between 0 and 1'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert abs(avg_top_share - 0.83) < 0.02\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
