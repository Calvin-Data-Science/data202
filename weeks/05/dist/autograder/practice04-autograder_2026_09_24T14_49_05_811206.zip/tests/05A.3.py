OK_FORMAT = True

test = {   'name': '05A.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert abs(birds['mean_loudness'].mean() - X.values.mean()) < 1e-06, 'mean_loudness should be a mean across each row (axis=1)'\n"
                                               ">>> assert list(cluster_profile.columns) == ['n_clips', 'loudest_band', 'mean_loudness']\n"
                                               '>>> assert len(cluster_profile) == 5\n'
                                               ">>> assert cluster_profile['loudest_band'].is_monotonic_increasing, 'sort by loudest_band, lowest first'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert cluster_profile['n_clips'].sum() == 4268\n"
                                               ">>> assert cluster_profile['loudest_band'].iloc[0] < 6 and cluster_profile['loudest_band'].iloc[-1] > 15\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
