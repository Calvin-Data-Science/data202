OK_FORMAT = True

test = {   'name': '05C.2',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert 1 <= n_90 <= 64, 'n_90 is a number of components, between 1 and 64'\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> assert n_90 == 5\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
