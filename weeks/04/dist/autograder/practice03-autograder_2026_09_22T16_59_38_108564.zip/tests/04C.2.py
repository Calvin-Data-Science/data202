OK_FORMAT = True

test = {   'name': '04C.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert list(life_long.columns) == ['country', 'year', 'life_exp'], 'life_long should have exactly the columns country, year, life_exp'\n"
                                               ">>> assert len(life_long) == len(life_wide) * 12, 'life_long should have one row per country per year'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert life_long.shape == (1704, 3)\n'
                                               ">>> row = life_long[(life_long['country'] == 'Afghanistan') & (life_long['year'] == 1952)]\n"
                                               ">>> assert abs(row['life_exp'].iloc[0] - 28.8) < 0.01\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
