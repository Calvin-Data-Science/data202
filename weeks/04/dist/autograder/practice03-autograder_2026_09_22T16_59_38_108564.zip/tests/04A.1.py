OK_FORMAT = True

test = {   'name': '04A.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert n_duplicate_country_rows > n_duplicate_country_year_rows, 'country alone should have far more duplicates than the country+year pair'\n"
                                               ">>> assert n_duplicate_country_year_rows == 0, 'country + year together should uniquely identify every row'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert n_duplicate_country_rows == 1562\n>>> assert n_duplicate_country_year_rows == 0\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
