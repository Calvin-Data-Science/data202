OK_FORMAT = True

test = {   'name': '04B.1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert set(gapminder.columns) == {'country', 'year', 'gdp_pcap', 'life_exp'}\n"
                                               ">>> assert len(gapminder) == len(gdp_long), 'every gdp_long row should have found a life_long match'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert gapminder.shape == (1704, 4)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
