OK_FORMAT = True

test = {   'name': '04A.2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(missing_from_region, list), 'missing_from_region should be a list'\n"
                                               ">>> assert len(missing_from_region) > 0, 'at least a few countries should be missing from country_region'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert missing_from_region == ['Congo, Dem. Rep.', 'Hong Kong, China', 'Korea, Rep.', 'Puerto Rico', 'Reunion']\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
