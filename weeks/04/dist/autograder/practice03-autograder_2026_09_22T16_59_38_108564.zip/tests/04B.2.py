OK_FORMAT = True

test = {   'name': '04B.2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(gapminder_with_regions) == len(gapminder), 'gapminder_with_regions should keep every row from gapminder'\n"
                                               ">>> assert n_missing_continent > 0, 'some rows should still be missing a continent, from the 3 countries not in country_region_fixed'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert gapminder_with_regions.shape == (1704, 5)\n>>> assert n_missing_continent == 36\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
