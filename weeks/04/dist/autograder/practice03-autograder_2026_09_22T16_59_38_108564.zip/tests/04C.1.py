OK_FORMAT = True

test = {   'name': '04C.1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> assert list(gdp_long.columns) == ['country', 'year', 'gdp_pcap'], 'gdp_long should have exactly the columns country, year, gdp_pcap'\n"
                                               ">>> assert len(gdp_long) == len(gdp_wide) * 12, 'gdp_long should have one row per country per year'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert gdp_long.shape == (1704, 3)\n'
                                               ">>> row = gdp_long[(gdp_long['country'] == 'Afghanistan') & (gdp_long['year'] == 1952)]\n"
                                               ">>> assert abs(row['gdp_pcap'].iloc[0] - 779) < 0.01\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
