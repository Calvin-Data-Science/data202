OK_FORMAT = True

test = {   'name': '04A.3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> assert len(still_missing_countries) < len(missing_from_region), 'fixing the two spelling mismatches should shrink the missing-countries list'\n"
                                               ">>> assert 'Congo, Dem. Rep.' not in still_missing_countries, 'Congo, Dem. Rep. should now be matched after the rename'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert still_missing_countries == ['Hong Kong, China', 'Puerto Rico', 'Reunion']\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
